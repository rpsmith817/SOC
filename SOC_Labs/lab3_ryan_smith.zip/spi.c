// SPI IP FIFO testing
// SPI Shell Command
// Ryan Smith adapted from gpio.c by Jason Losh

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: Xilinx XUP Blackboard

// Hardware configuration:
//
// AXI4-Lite interface:
//   Mapped to offset of 0x20000
//
//

//-----------------------------------------------------------------------------

#include <stdlib.h>          // EXIT_ codes
#include <stdio.h>           // printf
#include <string.h>          // strcmp
#include "spi_ip.h"         // spi IP library

int main(int argc, char* argv[])	//reads in how many arguments and what they are.
{
	uint32_t val=0;

	//setup the map for use
	if(!spiOpen())
	{
		printf("we couldn't open it...");
		getchar();
		return EXIT_SUCCESS;
	}

	//explain, wait for input, fill up the fifo by pushing 15 times, explain, wait for input.
	printf("we are empty.\r\nfirst we will fill things up.\r\n");
	getchar();
	for(val=1;val<16;val++)
	{
		push_data(val);
		printf("we wrote %08lx\r\n", (unsigned long)val);
		getchar();
	}	
	printf("we should be full now\r\none more to overflow\r\n");
	getchar();
	
	//explain, fly the ov flag, ov flag, wait for input
	printf("now we will clear the flag");
	push_data(16);
	getchar();
	
	//clear ov flag, explain, wait for input
	clear_overflow();
	printf("now we will pop some reads");
	getchar();
	
	//pop 5 values, explain, wait (added pause between)
	val=get_data();
	printf("that value is %08lx\r\n", (unsigned long)val);
	val=get_data();
	getchar();	
	printf("that value is %08lx\r\n", (unsigned long)val);
	val=get_data();
	getchar();
	printf("that value is %08lx\r\n", (unsigned long)val);
	val=get_data();
	getchar();
	printf("that value is %08lx\r\n", (unsigned long)val);
	val=get_data();
	getchar();
	printf("that value is %08lx\r\nthat was 5 reads from the overflow condition, we should have 10 in the chamber\r\n", (unsigned long)val);
	getchar();

	//explain, wait, then empty
	printf("now we will empty things out fully.\r\n");
	uint8_t i;
	for(i=0;i<10;i++)
	{
		val=get_data();
	}
	getchar();
	printf("that is the end\r\nbuhbye\r\n");
	getchar();
//
//     int pin;
//     if (argc == 3)
//     {
//         gpioOpen();
//         pin = atoi(argv[1]);
//         if (strcmp(argv[2], "out") == 0)
//             selectPinPushPullOutput(pin);
//         else if (strcmp(argv[2], "od") == 0)
//             selectPinOpenDrainOutput(pin);
//         else if (strcmp(argv[2], "in") == 0)
//             selectPinDigitalInput(pin);
//         else if (strcmp(argv[2], "high") == 0)
//             setPinValue(pin, 1);
//         else if (strcmp(argv[2], "low") == 0)
//             setPinValue(pin, 0);
//         else if (strcmp(argv[2], "status") == 0)
//             if (getPinValue(pin))
//                 printf("pin was high (1)\n");
//             else
//                 printf("pin was low (0)\n");
//         else
//             printf("argument %s not expected\n", argv[2]);
//     }

//     else if (argc == 2 && (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--help") == 0))
//     {
//         printf("  usage:\n");
//         printf("  gpio PIN out           make the pin a push-pull output\n");
//         printf("  gpio PIN od            make the pin an open drain output\n");
//         printf("  gpio PIN in            make the pin an input\n");
//         printf("  \n");
//         printf("  gpio PIN high        /  set the pin high\n");
//         printf("  gpio PIN low           set the pin low\n");
//         printf("  gpio PIN status        get the pin status\n");
//         printf("  \n");
//         printf("  gpio PIN int pos_edge  positive-edge interrupt\n");
//         printf("  gpio PIN int neg_edge  negative-edge interrupt\n");
//         printf("  gpio PIN int both_edge both-edge interrupt\n");
//         printf("  gpio PIN int high      high-level interrupt\n");
//         printf("  gpio PIN int low       low-level interrupt\n");
//         printf("  gpio PIN int off       disable interrupt\n");
//         printf("  gpio PIN int clear     clear interrupt\n");
//         printf("  \n");
//         printf("  where PIN = [0, 31]\n");
//     }
//     else
//         printf("  command not understood\n");
    return EXIT_SUCCESS;
}

