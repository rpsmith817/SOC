// SPI IP FIFO testing
// SPI Shell Command
// Ryan Smith adapted from gpio.c by Jason Losh

//-----------------------------------------------------------------------------
// Hardware Target
//-----------------------------------------------------------------------------

// Target Platform: Xilinx XUP Blackboard

// Hardware configuration:
//
// AXI4-Lite interface:
//   Mapped to offset of 0x20000
//
//

//-----------------------------------------------------------------------------

#include <stdlib.h>          // EXIT_ codes
#include <stdio.h>           // printf
#include <string.h>          // strcmp
#include <stdint.h>			// uint
#include "spi_ip.h"         // spi IP library

#define BRDCLKMAX 25000000
#define BRDCLKMIN 100000


//convert from an integer into an ascii output.
void intToAlpha(uint32_t in, char* buf)
{
    uint32_t val=in;        //set val to input so we can manipulate it without worry
    uint32_t intermediate=0;
    uint8_t len=0;            //an iterator to hold some length
    uint8_t j;
    int16_t i;

    //shortcut if we are 0.
    if(in==0)
    {
        buf[0]='0';
        buf[1]='\0';
        return;
    }

    //get length
    while(val != 0)
    {
        val /= 10;
        len++;
    }    


    //bounds. If len extends beyond 10 digits then something has gone wrong and we should yell about it.
    if(len>11)
    {
        for(i=0;i<10;i++)
        {
            buf[i]='!';
        }
        buf[10]='\0';
        return;
    }

    
    //otherwise we can continue.
    val=1;
    //loop through to get the value into the output buffer
    for(i=len-1;i>-1;i--)
    {
        for(j=0; j<i; j++)
        {
            val*=10;
        }
        intermediate = ((in/val));
        intermediate = intermediate %10;
        buf[len-1-i] = intermediate +'0';
        val=1;
    }

    //terminate the string
    buf[len] = '\0';
    return;
}


//take input clockrate and put the right ibrd+fbrd into BRD_reg so we output tht clock rate.
void setClockRate(int clockRate)
{
	char buf[256];
	long long big_clk = 6400000000LL;			//assuming 100MHz clk
	long long big_baud = (big_clk/clockRate);
	uint32_t ibrd_val = (uint32_t)big_baud/64;	//this might truncate, make sure input is within bounds external to this function.	

	if(ibrd_val == 0){return;}				//if ibrd is 0 then baud will be greater than clock rate, so gtfo. Handle other sanitization at input.

	uint32_t fbrd_val = (uint32_t)(big_baud - (ibrd_val*64));	//this is unlikely to truncate.

	volatile uint32_t the_brd = big_baud;	//big baud is already the value, no need to do weird math to get at the other values, except for debugging.	

	intToAlpha(the_brd,buf);
	printf("the_brd raw is:");
	printf(buf);
	printf("\r\n");
	
	intToAlpha(big_baud,buf);
	printf("big_baud: ");
	printf(buf);
	printf("\r\n");
	
	intToAlpha(ibrd_val,buf);
	printf("ibrd: ");
	printf(buf);
	printf("\r\n");
	
	intToAlpha(fbrd_val,buf);
	printf("fbrd: ");
	printf(buf);
	printf("\r\n");
	
	
	
	//then push the brd
	set_brd(the_brd);
}

uint32_t strto32_t(char* buf)
{
	uint32_t val=0;
	uint32_t tens=1;
	uint8_t len = strlen(buf);
	uint8_t i;
	

	if(len>8) return 0;	//uint32 largest value is 4,294,967,295, or 10 places large, but our input should be between 25mhz and 100khz, so we need 25,000,000 as max, or 8 length

	//set initial tens value
    for(i=1;i<len;i++)
    {
        tens*=10;
    }

    //reset iterator
    i=0;

    //loop through each idx
    while(len!=0)
    {
        val += ((buf[i++]-'0') * tens);       //add to value the numeric value of field times the tens place that it is in.
        tens/=10;                               //divide by tens to reduce tens place
        len--;                                    //iterate down
    }

	return val;
}




int main(int argc, char* argv[])	//reads in how many arguments and what they are, which we don't usually care about but maybe we will later so lets preserve the form for now.
{
//setup the maps for use
	uint8_t check =0;
	check = spiOpen();
	if(check == 0)
	{
		printf("ERROR:Failed to open map");
		return EXIT_SUCCESS;
	}
// 	else if(check == 1)
// 	{		
// 		printf("ERROR: Failed to open gpio map");
// 		getchar();
// 		return EXIT_SUCCESS;
// 	}
// 	else if(check == 2)
// 	{
// 		printf("ERROR: Failed to open spi map");
// 		getchar();
// 		return EXIT_SUCCESS;
// 	}

	
//grab the line
	char buf[256];
	uint32_t val;
	printf("Enter the clockrate: ");

	if (fgets(buf, sizeof(buf), stdin) != NULL) {	//read line
        buf[strcspn(buf, "\r\n")] = '\0';				//sanitize input
    } else {
        printf("Error reading input.\r\n");
		return EXIT_SUCCESS;
    }
	val=strto32_t(buf);								//pull entered value into int
	if(!val)										//if NULL then something went wrong
	{
		printf("Input error...\r\n");
		return EXIT_SUCCESS;
	}
	else if(val > BRDCLKMAX || val < BRDCLKMIN)
	{
		printf("Input out of bounds.\r\n");
		return EXIT_SUCCESS;
	}
	
	
	setClockRate(val);
	intToAlpha(val,buf);
	printf("Clock rate set to input value of:");
	printf(buf);
	printf("\r\n");
	
	val=get_brd();
	printf("BRD register set to: ");
	intToAlpha(val, buf);
	printf(buf);
	printf("\r\n");
	getchar();
	

	
//
//     int pin;
//     if (argc == 3)
//     {
//         gpioOpen();
//         pin = atoi(argv[1]);
//         if (strcmp(argv[2], "out") == 0)
//             selectPinPushPullOutput(pin);
//         else if (strcmp(argv[2], "od") == 0)
//             selectPinOpenDrainOutput(pin);
//         else if (strcmp(argv[2], "in") == 0)
//             selectPinDigitalInput(pin);
//         else if (strcmp(argv[2], "high") == 0)
//             setPinValue(pin, 1);
//         else if (strcmp(argv[2], "low") == 0)
//             setPinValue(pin, 0);
//         else if (strcmp(argv[2], "status") == 0)
//             if (getPinValue(pin))
//                 printf("pin was high (1)\n");
//             else
//                 printf("pin was low (0)\n");
//         else
//             printf("argument %s not expected\n", argv[2]);
//     }

//     else if (argc == 2 && (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--help") == 0))
//     {
//         printf("  usage:\n");
//         printf("  gpio PIN out           make the pin a push-pull output\n");
//         printf("  gpio PIN od            make the pin an open drain output\n");
//         printf("  gpio PIN in            make the pin an input\n");
//         printf("  \n");
//         printf("  gpio PIN high        /  set the pin high\n");
//         printf("  gpio PIN low           set the pin low\n");
//         printf("  gpio PIN status        get the pin status\n");
//         printf("  \n");
//         printf("  gpio PIN int pos_edge  positive-edge interrupt\n");
//         printf("  gpio PIN int neg_edge  negative-edge interrupt\n");
//         printf("  gpio PIN int both_edge both-edge interrupt\n");
//         printf("  gpio PIN int high      high-level interrupt\n");
//         printf("  gpio PIN int low       low-level interrupt\n");
//         printf("  gpio PIN int off       disable interrupt\n");
//         printf("  gpio PIN int clear     clear interrupt\n");
//         printf("  \n");
//         printf("  where PIN = [0, 31]\n");
//     }
//     else
//         printf("  command not understood\n");
    return EXIT_SUCCESS;
}

